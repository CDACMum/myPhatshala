import os
HERE = os.path.dirname(os.path.abspath(__file__))
BODY = body(HERE)

META = dict(
    module='02-data-and-storage', lesson='01-structured-semi-structured-unstructured-data', n='2.1',
    module_label='Module 2 · Data and Storage',
    title='Structured, semi-structured and unstructured data',
    desc='Structured, semi-structured and unstructured data explained with a real canteen data drop: CSV orders, JSON app events with schema drift, feedback text and an image. Schema-on-write vs schema-on-read, how to read each shape in Python, where each one is stored, and how unstructured data becomes tables. Beginner to Advanced, animations, Python exercises and a program for your PC.',
    og_desc='Only the orders file fit in a table. Learn the three shapes of data, schema-on-read, and how each is stored and analysed.',
    minutes=26, level='Beginner → Advanced',
    lead='Real data rarely arrives as one neat table. It comes as tables, as JSON events whose fields keep changing, and as text, photos and video. This lesson creates all three shapes on your computer, reads each one in Python, and shows how big data platforms store and analyse them: schema-on-write, schema-on-read, and extraction.',
    chips=['Runs in your browser (Python)', '3 real-time scenarios', 'Real data drop on your PC'],
)

RUN = dict(
    heading='Read three shapes of data in Python',
    intro='<p>Three small inputs, one of each shape, are written as Python strings so they run anywhere. Watch how much code each shape needs before you can count something. Then, in the challenges, classify data, flatten nested JSON, handle schema drift and extract fields from text.</p>',
    code='''import csv, io, json

# STRUCTURED: fixed columns
orders_csv = """order_id,item,amount
O1,poha,30
O2,chai,20
O3,poha,30
O4,samosa,15"""

# SEMI-STRUCTURED: labelled fields, not always the same ones
events = """{"event": "pay", "user": "U7", "amount": 20}
{"event": "open_app", "user": "U36"}
{"event": "pay", "user": "U9", "amount": 25, "device": {"os": "ios"}}"""

# UNSTRUCTURED: just text
feedback = "Poha was great. Samosa was cold. UPI payment failed. Poha again!"

revenue = {}
for row in csv.DictReader(io.StringIO(orders_csv)):
    revenue[row["item"]] = revenue.get(row["item"], 0) + int(row["amount"])
print("Structured   -> revenue:", revenue)

paid = 0
for line in events.splitlines():
    e = json.loads(line)
    paid += e.get("amount", 0)            # the field may be missing
print("Semi-struct. -> paid in app:", paid)

mentions = feedback.lower().count("poha")
print("Unstructured -> 'poha' mentioned", mentions, "times")
''',
    anno=[
        ('for row in csv.DictReader(io.StringIO(orders_csv)):', 'Every row has the same columns, so <code>row["item"]</code> always works. This is <b>structured</b> data.'),
        ('    paid += e.get("amount", 0)            # the field may be missing', '<code>.get()</code> with a default is how you survive <b>optional fields</b> in semi-structured data. <code>e["amount"]</code> would crash on <code>open_app</code>.'),
        ('mentions = feedback.lower().count("poha")', 'Text has no fields, so we invent a measurement: a word count. Real systems use NLP, but the idea is the same: <b>extract</b>, then analyse.'),
    ],
    tasks=[
        dict(label='1 · Three shapes', hint='Press <b>Run</b>. Then add a line <code>O5,chai,20</code> to the CSV and an event without <code>amount</code>. Which part needed no code change?', code=None),
        dict(label='2 · Classify the data', hint='Decide the shape of each source. Change the answers you disagree with, then run to see the tally.',
             code='''sources = {
    "marks table in MySQL": "structured",
    "Instagram post photo": "unstructured",
    "weather API reply in JSON": "semi-structured",
    "server log lines with key=value pairs": "semi-structured",
    "recorded customer call": "unstructured",
    "Excel sheet of fees paid": "structured",
}
from collections import Counter
for s, kind in sources.items():
    print(f"{kind:16} {s}")
print(Counter(sources.values()))
'''),
        dict(label='3 · Flatten nested JSON', hint='Tables need flat columns. This function turns <code>{"device": {"os": "ios"}}</code> into <code>device.os</code>. Add a nested <code>location</code> with <code>city</code> and try it.',
             code='''import json

def flatten(d, prefix=""):
    out = {}
    for k, v in d.items():
        key = prefix + k
        if isinstance(v, dict):
            out.update(flatten(v, key + "."))
        else:
            out[key] = v
    return out

e = json.loads('{"event": "pay", "amount": 25, "device": {"os": "ios", "app_version": "2.0"}}')
print(flatten(e))
'''),
        dict(label='4 · Detect schema drift', hint='Compare the fields of each batch of events with yesterday’s known fields and report anything new or missing.',
             code='''import json
known = {"event", "user", "amount"}
today = ['{"event": "pay", "user": "U1", "amount": 20}',
         '{"event": "pay", "user": "U2", "amount": 25, "device": {"os": "android"}}',
         '{"event": "pay", "userId": "U3", "amount": 15}']
for line in today:
    keys = set(json.loads(line))
    new, missing = keys - known, known - keys
    if new or missing:
        print("DRIFT:", "new", sorted(new), "missing", sorted(missing))
'''),
        dict(label='5 · Text to a table (advanced)', hint='Tag each comment with a topic and a sentiment using keyword rules, and print a small table. Add a rule for “queue”.',
             code='''comments = ["Samosa was cold today", "UPI payment failed twice", "Chai is the best on campus",
            "Poha too salty", "Loved the vada pav", "Long queue at lunch"]
topics = {"payment": ["upi", "payment"], "food": ["samosa", "poha", "chai", "vada"]}
negative = ["cold", "failed", "salty", "long"]

print(f"{'topic':8} {'sentiment':9} comment")
for c in comments:
    low = c.lower()
    topic = next((t for t, words in topics.items() if any(w in low for w in words)), "other")
    sentiment = "negative" if any(w in low for w in negative) else "positive"
    print(f"{topic:8} {sentiment:9} {c}")
'''),
        dict(label='6 · Metadata for files (advanced)', hint='Unstructured files are found through structured metadata. Build a metadata table and query it: which canteen uploaded the most bytes?',
             code='''files = [("photos/c001/menu.jpg", 1_800_000), ("photos/c002/menu.jpg", 2_100_000),
         ("cctv/c001/0900.mp4", 350_000_000), ("feedback/c002/day1.txt", 7_800)]
meta = []
for path, size in files:
    kind, canteen, name = path.split("/")
    meta.append({"canteen": canteen, "kind": kind, "file": name, "bytes": size})
by_canteen = {}
for m in meta:
    by_canteen[m["canteen"]] = by_canteen.get(m["canteen"], 0) + m["bytes"]
for row in meta:
    print(row)
print("bytes per canteen:", by_canteen)
'''),
    ],
)
RUN['tasks'][0]['code'] = RUN['code']

PCRUN = dict(
    heading='Run it on your PC: one day of canteen data in three shapes',
    intro='<p>This program creates a folder <code>canteen_drop</code> with a structured <code>orders.csv</code> (2,000 orders), semi-structured <code>app_events.jsonl</code> (1,000 events; a new app version adds a nested field halfway), unstructured <code>feedback.txt</code> and a real PNG image. Then it reads each file and shows what you can learn from it. No extra libraries needed. Save it as <code>data_types.py</code>, run it, and open the files.</p>',
    items=[
        dict(title='Create and read all three shapes', file='data_types.py',
             cmd=open(os.path.join(HERE, 'data_types.py')).read() + '\n# In a terminal:  python data_types.py',
             output=open(os.path.join(HERE, 'data_types.out')).read(),
             note='Recorded from a real run; with the same random seed your output will match. Notice the JSON file is larger than the CSV with half the records: every event repeats its field names. <code>device</code> appears in only 400 events: schema drift.'),
    ],
)

TRACE = dict(
    heading='Discovering a schema while reading JSON',
    intro='<p>A schema-on-read tool scans records and builds the list of fields it has seen. Follow <code>schema</code> grow as each event is read, including the nested field from the new app version.</p>',
    code='''import json
lines = ['{"event": "open_app", "user": "U1"}',
         '{"event": "pay", "user": "U2", "amount": 20}',
         '{"event": "pay", "user": "U3", "amount": 25, "device": {"os": "ios"}}']

schema = {}
for line in lines:
    record = json.loads(line)
    for key, value in record.items():
        schema[key] = type(value).__name__
print(schema)
''',
    notes={6: 'Schema starts empty :: Nothing is decided before the data arrives.',
           (10, 5): 'Optional field :: amount appears only in payment events.',
           (10, 9): 'Nested field :: device is a dict: a structure inside a record.'},
)

WORKED_INTRO = 'Four problems on the three shapes: sizing, drift, extraction and storage planning. Each runs live and is traced.'
EXAMPLES = [
    dict(level='b', tag='Basics · self-description', title='Why is the JSON file bigger than the CSV?',
         problem='<p>The same order is stored as one CSV line and as one JSON object. Measure both and find how much of the JSON line is field names.</p>',
         inp='O1,poha,30,UPI vs {"order_id": "O1", "item": "poha", "amount": 30, "mode": "UPI"}',
         approach=['Measure the length of each line.',
                   'Measure the length of the field names repeated in JSON.',
                   'Compare.'],
         code='''csv_line = 'O1,poha,30,UPI'
json_line = '{"order_id": "O1", "item": "poha", "amount": 30, "mode": "UPI"}'
names = sum(len(k) for k in ["order_id", "item", "amount", "mode"])
print("CSV bytes :", len(csv_line))
print("JSON bytes:", len(json_line))
print("field-name characters in JSON:", names)
''', notes={3: 'Repeated names :: CSV writes the names once in the header; JSON writes them in every record.'},
         tryit='For 1 billion events, that difference is many gigabytes. Binary formats like Avro and Parquet store the schema once (Lesson 2.2).'),
    dict(level='i', tag='Pipeline · drift', title='Count how many events use each app version',
         problem='<p>Events from app v1.9 have no <code>device</code> field; events from v2.0 have <code>device.app_version</code>. Count events per version without crashing on old events.</p>',
         inp='4 JSON events, 2 with device',
         approach=['Parse each line.',
                   'Read the nested field with safe defaults.',
                   'Count per version.'],
         code='''import json
lines = ['{"event": "pay"}', '{"event": "open_app"}',
         '{"event": "pay", "device": {"app_version": "2.0"}}',
         '{"event": "view_menu", "device": {"app_version": "2.0"}}']
count = {}
for line in lines:
    e = json.loads(line)
    version = e.get("device", {}).get("app_version", "1.9 (no device field)")
    count[version] = count.get(version, 0) + 1
print(count)
''', notes={6: 'Safe read :: .get("device", {}) returns an empty dict when the field is missing.'},
         tryit='What should the default be in a real report: "1.9", "unknown", or should these events be excluded? It is a business decision, not a coding one.'),
    dict(level='i', tag='Extraction · text', title='Turn comments into a topic count',
         problem='<p>Count negative comments per topic from free text using simple keyword rules: payment, food, cleanliness.</p>',
         inp='5 comments',
         approach=['Define keywords per topic.',
                   'Mark a comment negative if it has a negative word.',
                   'Count negative comments per topic.'],
         code='''comments = ["UPI failed again", "Samosa cold", "Tables dirty", "Payment failed", "Chai good"]
topics = {"payment": ["upi", "payment"], "food": ["samosa", "chai"], "cleanliness": ["dirty", "clean"]}
bad_words = ["failed", "cold", "dirty"]
counts = {}
for c in comments:
    low = c.lower()
    if any(b in low for b in bad_words):
        for t, words in topics.items():
            if any(w in low for w in words):
                counts[t] = counts.get(t, 0) + 1
print(counts)
''', notes={6: 'Rule :: Real systems use trained models; rules are a quick, explainable first step.'},
         tryit='“Chai good” is not counted. Add a positive count per topic too.'),
    dict(level='a', tag='Planning · storage', title='How much storage for one year of all three shapes?',
         problem='<p>Each of 400 canteens produces per day: 2,000 orders (40 bytes each), 50,000 app events (300 bytes), 300 comments (60 bytes), 10 photos (2 MB) and 8 hours of CCTV at 1 GB per hour. Estimate one year of storage per shape, in TB.</p>',
         inp='400 canteens · 365 days',
         approach=['Bytes per day per canteen for each shape.',
                   'Multiply by canteens and days.',
                   'Convert to TB and compare.'],
         code='''canteens, days = 400, 365
per_day = {"structured (orders)": 2000 * 40,
           "semi-structured (events)": 50_000 * 300,
           "unstructured (text+photos)": 300 * 60 + 10 * 2_000_000,
           "unstructured (CCTV)": 8 * 1_000_000_000}
for shape, b in per_day.items():
    print(f"{shape:28} {b * canteens * days / 1e12:10.3f} TB")
''', notes={2: 'Per canteen :: Write every shape in bytes per day first.'},
         tryit='Orders are a tiny fraction; video dominates. That is why unstructured data needs cheap object storage, not database disks.'),
]

QUIZ = [
    dict(q='Beginner: A table of student marks with fixed columns is…', options=['Structured', 'Semi-structured', 'Unstructured', 'Not data'], answer=0,
         why='Fixed columns with a known schema = <b>structured</b>.'),
    dict(q='Beginner: Which of these is usually semi-structured?', options=['A JPEG photo', 'A JSON event from an app', 'An MP3 song', 'A bank ledger table'], answer=1,
         why='JSON carries field names (keys) in every record, but fields can vary: semi-structured.'),
    dict(q='Beginner: Which shape makes up the largest share of the world\'s data?', options=['Structured', 'Semi-structured', 'Unstructured', 'All equal'], answer=2,
         why='Text, images, audio and video are by far the biggest share.'),
    dict(q='Intermediate: “Schema-on-read” means…', options=['The schema is checked before storing data', 'Data is stored as it arrives and a structure is applied when it is read', 'Data has no schema ever', 'Only databases can read it'], answer=1,
         why='Data lakes and tools like Spark apply structure at read time.'),
    dict(q='Intermediate: Why was app_events.jsonl larger than orders.csv despite having fewer records?', options=['JSON is compressed', 'Every JSON record repeats its field names', 'CSV deletes data', 'JSON stores images'], answer=1,
         why='Self-describing records repeat keys like "event" and "user" on every line.'),
    dict(q='Intermediate: A new field appears in incoming JSON events after an app update. This is called…', options=['Data skew', 'Schema drift', 'Replication', 'Sharding'], answer=1,
         why='Schema drift: the structure of incoming data changes over time.'),
    dict(q='Advanced: How do platforms usually make millions of photos searchable?', options=['Store them in a relational table as text', 'Store files in object storage plus a structured metadata table (path, date, labels)', 'Convert them to CSV', 'Delete them after a day'], answer=1,
         why='Files stay where storage is cheap; a metadata table makes them findable with SQL.'),
    dict(q='Advanced: In Python, which line survives a JSON event that has no "amount" field?', options=['e["amount"]', 'e.get("amount", 0)', 'e.amount', 'int(e)'], answer=1,
         why='.get() with a default handles optional fields; e["amount"] raises a KeyError.'),
]

REVISION = [
    '<b>Structured</b> = fixed columns (tables, CSV): SQL works directly; schema-on-write.',
    '<b>Semi-structured</b> = labelled, flexible records (JSON, XML, logs): schema-on-read; watch for <b>schema drift</b>.',
    '<b>Unstructured</b> = text, images, audio, video: extract fields (NLP, vision, OCR) before analysis.',
    'Unstructured is the biggest share; semi-structured logs grow fastest.',
    'JSON repeats field names in every record: flexible but larger.',
    'Store raw semi-structured data, then publish clean tables; keep files in object storage with a <b>metadata table</b>.',
    'Use <code>.get(key, default)</code> for optional fields; flatten nested JSON for tables.',
]
FAQ = [
    ('What is the difference between structured, semi-structured and unstructured data?', 'Structured data follows a fixed schema of rows and columns, like database tables. Semi-structured data has tags or keys describing each value but no rigid schema, so records can differ, like JSON or XML. Unstructured data has no predefined fields, like text, images, audio and video, and must be processed to extract information.'),
    ('Give examples of each type of data.', 'Structured: bank transactions, student marks, inventory tables. Semi-structured: JSON API responses, app event logs, XML files, IoT sensor messages. Unstructured: emails, PDFs, social media posts, photos, CCTV video, call recordings.'),
    ('What is schema-on-read and schema-on-write?', 'Schema-on-write defines the schema before loading and rejects data that does not match (traditional databases and warehouses). Schema-on-read stores data in its raw form and applies a schema when the data is read (data lakes, Hive external tables, Spark). The first gives fast, reliable queries; the second gives flexibility for changing and varied data.'),
    ('Is JSON structured or unstructured?', 'JSON is semi-structured. It has keys and values, and can be nested, but different records can have different keys, and there is no fixed table schema unless one is applied.'),
    ('How is unstructured data analysed?', 'By extracting structured information from it: text with NLP (keywords, sentiment, entities), images and video with computer vision (objects, faces, number plates), scanned documents with OCR, audio with speech-to-text. The extracted fields are then stored in tables and analysed with SQL or BI tools.'),
]

PRACTICE_INTRO = 'Exercises from easy to advanced, ending with two business decisions.'
PROBLEMS = [
    dict(level='easy', title='Name the shape', stmt='Print the shape of each item: a CSV of fees, a JSON weather reply, a WhatsApp voice note.', inp='3 items',
         code='''for item, shape in [("fees.csv", "structured"), ("weather.json", "semi-structured"), ("voice_note.opus", "unstructured")]:
    print(f"{item:16} {shape}")
''', explain='Look at the content: fixed columns, labelled flexible fields, or raw media.'),
    dict(level='easy', title='Read an optional field', stmt='Sum the <code>amount</code> of these events, treating a missing amount as 0.', inp='3 events, one without amount',
         code='''events = [{"amount": 20}, {"event": "open_app"}, {"amount": 25}]
print(sum(e.get("amount", 0) for e in events))
''', explain='45. Optional fields are normal in semi-structured data.'),
    dict(level='easy', title='Size of field names', stmt='How many characters do the keys of this JSON record use?', inp='{"event": "pay", "user": "U7", "amount": 20}',
         code='''import json
r = json.loads('{"event": "pay", "user": "U7", "amount": 20}')
print(sum(len(k) for k in r))
''', explain='15 characters of names in every record: the price of self-describing data.'),
    dict(level='medium', title='Flatten for a table', stmt='Flatten <code>{"user": "U9", "device": {"os": "ios", "app": {"version": "2.0"}}}</code> into dotted column names.', inp='nested JSON, 3 levels',
         code='''def flat(d, p=""):
    out = {}
    for k, v in d.items():
        if isinstance(v, dict): out.update(flat(v, p + k + "."))
        else: out[p + k] = v
    return out
print(flat({"user": "U9", "device": {"os": "ios", "app": {"version": "2.0"}}}))
''', explain='user, device.os, device.app.version: nested data becomes flat columns.'),
    dict(level='medium', title='Find new fields', stmt='Yesterday\'s events had keys {event, user, amount}. Today one event has {event, user, amount, coupon}. Print the new fields.', inp='two key sets',
         code='''known, today = {"event", "user", "amount"}, {"event", "user", "amount", "coupon"}
print("new fields:", today - known)
''', explain='Set difference is the simplest drift detector.'),
    dict(level='medium', title='Share of each shape', stmt='A platform stores 2 TB structured, 30 TB semi-structured and 268 TB unstructured data. Print each share in %.', inp='2, 30, 268 TB',
         code='''sizes = {"structured": 2, "semi-structured": 30, "unstructured": 268}
total = sum(sizes.values())
for k, v in sizes.items():
    print(f"{k:16} {v / total:.1%}")
''', explain='Unstructured data is usually the overwhelming majority by volume (numbers illustrative).'),
    dict(level='advanced', title='Keyword sentiment score', stmt='Score each comment: +1 per positive word, −1 per negative word. Print the average score.', inp='4 comments',
         code='''pos, neg = ["best", "loved", "great"], ["cold", "failed", "salty"]
comments = ["Chai is the best", "Samosa cold and salty", "Loved it", "UPI failed"]
scores = [sum(w in c.lower() for w in pos) - sum(w in c.lower() for w in neg) for c in comments]
print(scores, "average", sum(scores) / len(scores))
''', explain='A crude but explainable way to turn text into a number for dashboards.'),
    dict(level='business', title='Store CCTV or not?', stmt='CCTV produces 8 GB per canteen per day for 400 canteens. Object storage costs ₹1.8 per GB per month. What is the monthly cost of keeping 30 days of video?', inp='8 GB × 400 × 30 days',
         code='''gb = 8 * 400 * 30
print(f"{gb:,} GB stored -> Rs {gb * 1.8:,.0f} per month")
''', explain='About ₹1.73 lakh per month (prices illustrative). Many teams keep video briefly and keep only the extracted counts long term.'),
    dict(level='business', title='Fix drift or ignore it?', stmt='The new <code>coupon</code> field appears in 30% of 2 lakh daily payments, average discount ₹12. If the pipeline ignores the field, how much discount per day is invisible to finance?', inp='2,00,000 × 30% × ₹12',
         code='''print("Rs", int(200_000 * 0.30 * 12), "of discounts per day not visible")
''', explain='₹7.2 lakh per day: ignoring schema drift is a business problem, not just a technical one.'),
]

SCN_INTRO = 'Questions on data types asked in data engineering and analyst interviews. Decide your answer first, then open the model answer.'
SCENARIOS = open(os.path.join(HERE, 'scenarios.html'), encoding='utf-8').read()
