import os
HERE = os.path.dirname(os.path.abspath(__file__))
BODY = body(HERE)

META = dict(
    module='02-data-and-storage', lesson='04-nosql-databases', n='2.4',
    module_label='Module 2 · Data and Storage',
    title='NoSQL databases: key-value, document, wide-column and graph',
    desc='The four NoSQL families explained with one canteen app: key-value for carts (Redis), document for menus (MongoDB), wide-column for order history (Cassandra) and graph for recommendations (Neo4j), plus why payments stay relational. Real runs with Python\'s standard library show key lookups, JSON queries, partition-key SEARCH vs full SCAN, and a graph path. SQL vs NoSQL, ACID vs BASE, query-first design and hot partitions. Beginner to Advanced.',
    og_desc='Carts, menus, order history, recommendations: four questions, four NoSQL databases. Learn when to use each, and when to stay with SQL.',
    minutes=30, level='Beginner → Advanced',
    lead='Relational databases are excellent, but not at everything. NoSQL databases each specialise in one access pattern and scale out across many machines. This lesson tries all four families on your computer with plain Python, shows the design rule that matters most (model tables around your queries), and shows how real apps combine several databases.',
    chips=['Runs in your browser (Python)', '3 real-time scenarios', 'Four data models on your PC'],
)

RUN = dict(
    heading='Four data models in a few lines of Python',
    intro='<p>Each family is modelled with Python structures: a dictionary as a key-value store, a list of JSON-like documents, a dictionary of partitions for a wide-column table, and an adjacency map for a graph. Run it and see which question each one answers easily.</p>',
    code='''# KEY-VALUE: one key, one value
carts = {"cart:U42": {"items": ["chai", "samosa"], "total": 50}}
print("KV       :", carts["cart:U42"])

# DOCUMENT: flexible records, query by any field
menus = [{"canteen": "C017", "city": "Pune", "veg_only": True},
         {"canteen": "C233", "city": "Nashik"},
         {"canteen": "C102", "city": "Pune", "timings": {"close": "20:00"}}]
print("DOCUMENT :", [m["canteen"] for m in menus if m.get("city") == "Pune"])

# WIDE-COLUMN: partition key -> rows sorted by clustering key (time)
orders_by_student = {"U42": [("12:58", "chai"), ("09:10", "poha")],
                     "U77": [("13:02", "dosa")]}
print("WIDE-COL :", sorted(orders_by_student["U42"], reverse=True))

# GRAPH: nodes and edges
ordered = {"Riya": ["chai", "poha"], "Kabir": ["chai", "samosa"], "Asha": ["samosa"]}
also = {item for person, items in ordered.items() if "chai" in items for item in items} - {"chai"}
print("GRAPH    : people who ordered chai also ordered", sorted(also))
''',
    anno=[
        ('print("KV       :", carts["cart:U42"])', 'A key-value store answers only “what is stored under this key?”, but answers it extremely fast.'),
        ('print("DOCUMENT :", [m["canteen"] for m in menus if m.get("city") == "Pune"])', 'Documents can be searched by fields inside them; missing fields are fine (<code>.get()</code>).'),
        ('print("WIDE-COL :", sorted(orders_by_student["U42"], reverse=True))', 'The partition key (student) leads straight to that student\'s rows, kept in time order. A different question needs a different table.'),
    ],
    tasks=[
        dict(label='1 · Four models', hint='Press <b>Run</b>. Add a cart for U77 and a menu for C301 with a new field <code>"combo"</code>. Did anything else need to change?', code=None),
        dict(label='2 · Key-value with expiry', hint='Real key-value stores support a TTL. Store an OTP that expires after 2 time units and read it at times 1 and 3.',
             code='''store = {}
def set_key(key, value, now, ttl):
    store[key] = (value, now + ttl)
def get_key(key, now):
    value, expires = store.get(key, (None, 0))
    return value if now < expires else None

set_key("otp:9876", 4521, now=0, ttl=2)
print("t=1:", get_key("otp:9876", 1))
print("t=3:", get_key("otp:9876", 3))
'''),
        dict(label='3 · Query inside documents', hint='Find canteens that sell anything under ₹25 by looking inside the nested <code>items</code> list.',
             code='''menus = [{"canteen": "C017", "items": [{"name": "poha", "price": 30}, {"name": "chai", "price": 15}]},
         {"canteen": "C233", "items": [{"name": "dosa", "price": 40}]},
         {"canteen": "C102", "items": [{"name": "tea", "price": 10}, {"name": "vada pav", "price": 25}]}]
cheap = [m["canteen"] for m in menus if any(i["price"] < 25 for i in m["items"])]
print(cheap)
'''),
        dict(label='4 · One table per query', hint='The orders table is keyed by student. Product now asks “orders per canteen”. Build a second table (denormalised copy) keyed by canteen.',
             code='''orders = [("U42", "C017", "12:58", "chai"), ("U77", "C017", "13:02", "dosa"), ("U42", "C102", "09:10", "poha")]
by_student, by_canteen = {}, {}
for student, canteen, t, item in orders:
    by_student.setdefault(student, []).append((t, canteen, item))
    by_canteen.setdefault(canteen, []).append((t, student, item))     # same data, second shape
print("by student:", by_student)
print("by canteen:", by_canteen)
'''),
        dict(label='5 · Find a hot partition (advanced)', hint='Count rows per partition for two candidate keys. Which key spreads the load better?',
             code='''import random
from collections import Counter
random.seed(4)
cities = ["Pune"] * 300 + ["Nashik"] * 50 + ["Nagpur"] * 30 + ["Satara"] * 20
canteens = [(f"C{i:03d}", c) for i, c in enumerate(cities)]
orders = [random.choice(canteens) for _ in range(40_000)]
by_city = Counter(c for _, c in orders)
by_canteen = Counter(k for k, _ in orders)
print("by city   : largest partition", max(by_city.values()), "rows of", len(orders))
print("by canteen: largest partition", max(by_canteen.values()), "rows, partitions:", len(by_canteen))
'''),
        dict(label='6 · Shortest path in a graph (advanced)', hint='Breadth-first search finds how two people are connected through what they ordered. Add Dev who ordered dosa, and Asha who ordered dosa too.',
             code='''from collections import deque
ordered = {"Riya": ["chai"], "Kabir": ["chai", "samosa"], "Asha": ["samosa"]}
graph = {}
for p, items in ordered.items():
    for i in items:
        graph.setdefault(p, set()).add(i); graph.setdefault(i, set()).add(p)

def path(a, b):
    q, seen = deque([[a]]), {a}
    while q:
        p = q.popleft()
        if p[-1] == b: return p
        for n in graph[p[-1]] - seen:
            seen.add(n); q.append(p + [n])
print(" -> ".join(path("Riya", "Asha")))
'''),
    ],
)
RUN['tasks'][0]['code'] = RUN['code']

PCRUN = dict(
    heading='Run it on your PC: four NoSQL models with the standard library',
    intro='<p>No database to install. The program uses Python\'s built-in <code>dbm</code> module as an on-disk key-value store, SQLite\'s JSON functions as a document store, a SQLite table with a compound primary key to behave like a wide-column table (and asks SQLite whether each query is a <b>SEARCH</b> or a full <b>SCAN</b>), and a dictionary graph with breadth-first search. Save it as <code>nosql_four.py</code> and run it.</p>',
    items=[
        dict(title='Key-value, document, wide-column and graph', file='nosql_four.py',
             cmd=open(os.path.join(HERE, 'nosql_four.py')).read() + '\n# In a terminal:  python nosql_four.py',
             output=open(os.path.join(HERE, 'nosql_four.out')).read(),
             note='Recorded from a real run with Python 3.13 on Linux. Key-value timings depend on which <code>dbm</code> engine your Python uses (shown in brackets). The wide-column lines are SQLite\'s own query plans: SEARCH with the partition key, SCAN without it.'),
    ],
)

TRACE = dict(
    heading='Writing one order into a partitioned table',
    intro='<p>A wide-column store hashes the partition key to pick a node, then keeps rows in the partition sorted by the clustering key. Follow three orders being placed on a 3-node cluster.</p>',
    code='''nodes = {0: {}, 1: {}, 2: {}}
orders = [("C017", 1258, "chai"), ("C233", 1302, "dosa"), ("C017", 910, "poha")]
for canteen, t, item in orders:
    node = sum(map(ord, canteen)) % 3
    partition = nodes[node].setdefault(canteen, [])
    partition.append((t, item))
    partition.sort()
print(nodes)
''',
    notes={4: 'Hash :: The partition key decides the node. Same key, same node, every time.',
           (7, 3): 'Sorted :: The 09:10 order goes before 12:58 inside C017\'s partition.'},
)

WORKED_INTRO = 'Four problems on choosing, sizing and designing NoSQL data. Each runs live and is traced.'
EXAMPLES = [
    dict(level='b', tag='Basics · choose', title='Pick a database family for each feature',
         problem='<p>Pick key-value, document, wide-column, graph or relational for: OTPs, student profiles with varying fields, 1 crore sensor readings a day per device, “friends of friends”, and fee payments.</p>',
         inp='5 features',
         approach=['Only by key and expiring → key-value.',
                   'Flexible records → document. Huge time-ordered writes → wide-column.',
                   'Relationships → graph. Money → relational.'],
         code='''picks = {"OTPs": "key-value", "student profiles": "document", "sensor readings": "wide-column",
         "friends of friends": "graph", "fee payments": "relational"}
for feature, family in picks.items():
    print(f"{feature:20} -> {family}")
''', notes={1: 'Access pattern :: Decide by how data is read and written.'},
         tryit='Add “full-text search over reviews”. That is usually a search engine (Elasticsearch/OpenSearch), another specialised store.'),
    dict(level='i', tag='Sizing · partitions', title='How big does one partition get?',
         problem='<p>An orders table is partitioned by <code>canteen</code> only. A busy canteen gets 3,000 orders a day of 200 bytes each. How large is its partition after 3 years, and with <code>(canteen, day)</code> instead?</p>',
         inp='3,000 orders/day · 200 bytes · 3 years',
         approach=['Rows per day × bytes × days.',
                   'With (canteen, day), each partition holds one day.',
                   'Compare with a guideline of keeping partitions well under ~100 MB.'],
         code='''per_day = 3000 * 200
three_years = per_day * 365 * 3
print(f"key canteen      : {three_years / 1e6:.0f} MB in ONE partition, still growing")
print(f"key (canteen,day): {per_day / 1e6:.1f} MB per partition, bounded")
''', notes={2: 'Unbounded :: A partition that grows forever eventually becomes slow to read and repair.'},
         tryit='Bucketing time into the key (day, week or month) is the standard way to bound partitions.'),
    dict(level='i', tag='Design · denormalise', title='Write once, read many shapes',
         problem='<p>The app needs “orders by student” and “orders by canteen”. In NoSQL we write each order to two tables. If there are 50 lakh orders a day of 150 bytes, how much is written per day, and why accept that?</p>',
         inp='50,00,000 orders · 150 bytes · 2 tables',
         approach=['Bytes per table per day.',
                   'Multiply by the number of query tables.',
                   'Compare with the cost of joins at read time.'],
         code='''orders, size, tables = 5_000_000, 150, 2
print(f"{orders * size * tables / 1e9:.2f} GB written per day ({tables} copies)")
''', notes={1: 'Trade :: Disk is cheap; reads at scale without joins are fast and predictable.'},
         tryit='Writes become 2× but every read hits one partition. Most NoSQL designs accept duplicate data to make reads simple.'),
    dict(level='a', tag='Consistency · quorum', title='Will a quorum read see the latest write?',
         problem='<p>With replication factor 3, a write is acknowledged by W replicas and a read asks R replicas. A read is guaranteed to see the latest write if R + W &gt; 3. Check combinations of ONE (1) and QUORUM (2).</p>',
         inp='RF = 3 · R, W in {1, 2}',
         approach=['List every (W, R) pair.',
                   'Check R + W > RF.',
                   'Print which are strongly consistent.'],
         code='''rf = 3
for w_name, w in [("ONE", 1), ("QUORUM", 2)]:
    for r_name, r in [("ONE", 1), ("QUORUM", 2)]:
        print(f"write {w_name:6} read {r_name:6} -> {'sees latest write' if r + w > rf else 'may read stale data'}")
''', notes={4: 'Overlap :: If read and write sets must overlap, at least one replica read has the newest value.'},
         tryit='This is how Cassandra tunes consistency per query. Lesson 3.4 connects it to the CAP theorem.'),
]

QUIZ = [
    dict(q='Beginner: Redis is mainly a…', options=['Graph database', 'Key-value store', 'Wide-column store', 'Data warehouse'], answer=1,
         why='Redis maps keys to values, usually in memory: caches, sessions, counters.'),
    dict(q='Beginner: Which NoSQL family stores flexible JSON records you can query by field?', options=['Key-value', 'Document', 'Wide-column', 'Graph'], answer=1,
         why='Document stores such as MongoDB.'),
    dict(q='Beginner: “Friends of friends who bought this” is easiest in a…', options=['Key-value store', 'Wide-column store', 'Graph database', 'CSV file'], answer=2,
         why='Graphs store relationships directly and traverse them.'),
    dict(q='Intermediate: In our wide-column table, why was “WHERE item = \'dosa\'” a SCAN?', options=['item is a reserved word', 'item is not part of the partition/primary key, so every row must be checked', 'SQLite is broken', 'The table was empty'], answer=1,
         why='With the key: SEARCH USING INDEX. Without: SCAN. Wide-column design means one table per query.'),
    dict(q='Intermediate: What does “query-first” data modelling mean?', options=['Write SQL before creating tables', 'Design tables around the questions the application will ask, duplicating data if needed', 'Always normalise', 'Query the data before storing it'], answer=1,
         why='NoSQL has few or no joins, so each important query gets a table or document shape.'),
    dict(q='Intermediate: Which is the best partition key for orders in a 400-canteen app?', options=['city', 'payment mode', '(canteen, day)', 'a constant value'], answer=2,
         why='Many values, even spread, bounded partitions, and it matches the main query.'),
    dict(q='Advanced: Why do most companies keep payments in a relational database?', options=['NoSQL cannot store numbers', 'Payments need multi-row ACID transactions and flexible queries for audits', 'Relational databases are always faster', 'NoSQL is not allowed for money by law'], answer=1,
         why='Debits and credits must commit together; reconciliation needs ad-hoc SQL.'),
    dict(q='Advanced: With replication factor 3, which read/write consistency pair guarantees reading the latest write?', options=['ONE / ONE', 'QUORUM / ONE', 'QUORUM / QUORUM', 'ANY / ONE'], answer=2,
         why='R + W = 2 + 2 = 4 > 3, so the sets overlap.'),
]

REVISION = [
    'NoSQL = <b>not only SQL</b>: non-relational models, flexible schemas, horizontal scaling, often BASE instead of ACID.',
    '<b>Key-value</b> (Redis, DynamoDB): get/put by key, TTL; caches, sessions, carts.',
    '<b>Document</b> (MongoDB): flexible JSON, query by fields; catalogs, profiles.',
    '<b>Wide-column</b> (Cassandra, HBase): partition key + clustering key; huge writes; fast only with the key (SEARCH vs SCAN).',
    '<b>Graph</b> (Neo4j): nodes + edges; paths, recommendations, fraud rings.',
    'Design <b>query-first</b>, denormalise, choose partition keys that spread load and stay bounded (avoid hot partitions).',
    'Payments stay relational; many apps use several databases (<b>polyglot persistence</b>).',
]
FAQ = [
    ('What are the types of NoSQL databases?', 'Four main types: key-value stores (Redis, DynamoDB) map keys to values; document stores (MongoDB, Couchbase) store JSON-like documents with flexible fields; wide-column stores (Cassandra, HBase) store rows grouped by partition key with many sorted columns; graph databases (Neo4j) store nodes and relationships for traversal queries.'),
    ('What is the difference between SQL and NoSQL databases?', 'SQL databases use fixed relational schemas, support joins and ad-hoc queries, and provide ACID transactions, typically scaling up on one server. NoSQL databases use other data models with flexible schemas, are designed to scale out across many machines, and often relax consistency or transaction scope for availability and performance. Data is modelled around specific queries rather than normalised.'),
    ('When should you use NoSQL instead of a relational database?', 'When the data volume or write rate exceeds what one relational server handles, when records have varying structure, when access is mostly by key with very low latency, or when the problem is about relationships. If you need complex transactions and flexible queries on moderately sized data, a relational database is usually better.'),
    ('What is a partition key in Cassandra?', 'The part of the primary key that is hashed to decide which nodes store a row. All rows with the same partition key are stored together and sorted by the clustering columns. Queries should specify the partition key; a good key distributes data evenly and keeps each partition bounded in size.'),
    ('What is BASE?', 'Basically Available, Soft state, Eventually consistent: a model in which the system prioritises availability, allows replicas to be temporarily out of date, and converges to a consistent state over time. It is contrasted with ACID transactions in relational databases.'),
]

PRACTICE_INTRO = 'Exercises from easy to advanced, ending with two business decisions.'
PROBLEMS = [
    dict(level='easy', title='Match the family', stmt='Print the NoSQL family of Redis, MongoDB, Cassandra, Neo4j and HBase.', inp='5 products',
         code='''for p, f in [("Redis", "key-value"), ("MongoDB", "document"), ("Cassandra", "wide-column"),
             ("Neo4j", "graph"), ("HBase", "wide-column")]:
    print(f"{p:9} {f}")
''', explain='HBase is the Hadoop ecosystem\'s wide-column store, built on HDFS.'),
    dict(level='easy', title='Read a missing field', stmt='Print each canteen\'s closing time, or “not given” when the document has no <code>timings</code>.', inp='3 documents',
         code='''docs = [{"canteen": "C017"}, {"canteen": "C102", "timings": {"close": "20:00"}}, {"canteen": "C233", "timings": {}}]
for d in docs:
    print(d["canteen"], d.get("timings", {}).get("close", "not given"))
''', explain='Flexible documents need safe reads for optional and nested fields.'),
    dict(level='easy', title='Key naming', stmt='Build Redis-style keys <code>type:id</code> for carts of U1, U2, U3.', inp='3 users',
         code='''print([f"cart:{u}" for u in ["U1", "U2", "U3"]])
''', explain='Prefixes like cart:, session:, otp: keep a flat key space organised.'),
    dict(level='medium', title='Rows per partition', stmt='Count orders per partition for key (canteen, day) and print the largest partition.', inp='6 orders',
         code='''from collections import Counter
orders = [("C017", "Mon"), ("C017", "Mon"), ("C017", "Tue"), ("C233", "Mon"), ("C017", "Mon"), ("C102", "Tue")]
c = Counter(orders)
print(c, "largest:", c.most_common(1))
''', explain='(C017, Mon) has 3 rows. Monitoring partition sizes catches hot keys early.'),
    dict(level='medium', title='Latest N in a partition', stmt='From a student\'s partition of (time, item), return the latest 2 orders.', inp='4 orders',
         code='''partition = [("09:10", "poha"), ("12:58", "chai"), ("11:30", "dosa"), ("08:05", "tea")]
print(sorted(partition, reverse=True)[:2])
''', explain='Wide-column stores keep rows sorted by the clustering key, so this is a cheap read.'),
    dict(level='medium', title='Two hops', stmt='Find items ordered by people who ordered samosa, excluding samosa.', inp='orders of 3 people',
         code='''ordered = {"Kabir": {"chai", "samosa"}, "Asha": {"samosa", "dosa"}, "Riya": {"poha"}}
people = [p for p, items in ordered.items() if "samosa" in items]
print(sorted(set().union(*(ordered[p] for p in people)) - {"samosa"}))
''', explain='chai and dosa: a two-hop traversal, the basis of “customers also bought”.'),
    dict(level='advanced', title='Quorum size', stmt='Print the QUORUM size (majority) for replication factors 3, 5 and 7.', inp='RF 3, 5, 7',
         code='''for rf in [3, 5, 7]:
    print("RF", rf, "-> quorum", rf // 2 + 1)
''', explain='Quorum = floor(RF/2) + 1. Reads and writes at quorum always overlap.'),
    dict(level='business', title='Cache hit savings', stmt='5,000 requests/s during a 10-minute sale; 98% are served by the cache. How many database queries are avoided?', inp='5,000/s × 600 s × 98%',
         code='''total = 5000 * 600
print(f"{int(total * 0.98):,} database queries avoided of {total:,}")
''', explain='29.4 lakh queries avoided: the database only needs to handle normal load.'),
    dict(level='business', title='One more database?', stmt='A graph database would cost ₹1.2 lakh/month to run and save fraud losses of ₹40,000/month. Should the team add it now?', inp='cost vs saving',
         code='''cost, saving = 120_000, 40_000
print("net per month: Rs", saving - cost, "->", "add it" if saving > cost else "not yet; try SQL or batch graph analysis first")
''', explain='Every extra database adds cost and operations work; add it when the benefit clearly exceeds both (figures illustrative).'),
]

SCN_INTRO = 'NoSQL questions asked in backend and data engineering interviews. Decide your answer first, then open the model answer.'
SCENARIOS = open(os.path.join(HERE, 'scenarios.html'), encoding='utf-8').read()
