import os
HERE = os.path.dirname(os.path.abspath(__file__))
BODY = body(HERE)

META = dict(
    module='02-data-and-storage', lesson='02-file-formats-csv-json-avro-parquet-orc', n='2.2',
    module_label='Module 2 · Data and Storage',
    title='File formats: CSV, JSON, Avro, Parquet and ORC',
    desc='Big data file formats compared on 10 lakh real orders: CSV 37.7 MB, JSON 104.7 MB, Avro 8.8 MB, Parquet 10.7 MB, ORC 4.2 MB, and a revenue query 10× faster from Parquet than CSV with the same reader. Row vs columnar storage, compression codecs, dictionary encoding, column pruning, predicate pushdown, splittability and Avro schema evolution. Beginner to Advanced, animations, Python exercises and a benchmark for your PC.',
    og_desc='Same data, a quarter of the size, ten times faster to query. Learn why columnar formats like Parquet and ORC win for analytics.',
    minutes=30, level='Beginner → Advanced',
    lead='How data is laid out on disk decides how big it is, how fast it can be queried, and whether it can survive schema changes. This lesson writes the same 10 lakh orders as CSV, JSON, Avro, Parquet and ORC, measures size and query time, and opens a Parquet file to show the schema and statistics that make it fast.',
    chips=['Runs in your browser (Python)', '3 real-time scenarios', 'Format benchmark on your PC'],
)

RUN = dict(
    heading='Row vs column layout, measured with real compression',
    intro='<p>The same 20,000 orders are laid out two ways: row by row (like CSV) and column by column (like Parquet). Both are compressed with <code>zlib</code>, a real compressor in Python\'s standard library. Then the challenges add dictionary encoding, column pruning, min/max skipping and schema evolution.</p>',
    code='''import random, zlib
random.seed(1)
items = ["chai", "coffee", "vada pav", "samosa", "poha"]
rows = [(i, f"C{random.randint(1, 400):03d}", random.choice(items),
         random.choice([15, 20, 25, 30]), random.choice(["UPI", "cash"])) for i in range(20_000)]

# ROW layout: one line per order
row_text = "\\n".join(",".join(map(str, r)) for r in rows).encode()

# COLUMN layout: all values of column 0, then column 1, ...
columns = list(zip(*rows))
col_text = "\\n".join(",".join(map(str, c)) for c in columns).encode()

print("row layout     :", len(row_text), "bytes ->", len(zlib.compress(row_text)), "compressed")
print("column layout  :", len(col_text), "bytes ->", len(zlib.compress(col_text)), "compressed")

amount_only = ",".join(map(str, columns[3])).encode()
print("amount column alone:", len(amount_only), "bytes (what SUM(amount) needs)")
''',
    anno=[
        ('columns = list(zip(*rows))', '<code>zip(*rows)</code> turns rows into columns: all IDs together, all canteens together, and so on. This is the core idea of Parquet and ORC.'),
        ('print("column layout  :", len(col_text), "bytes ->", len(zlib.compress(col_text)), "compressed")', 'Same bytes before compression, but similar values side by side compress better.'),
        ('amount_only = ",".join(map(str, columns[3])).encode()', 'A query on one column reads only that column: <b>column pruning</b>.'),
    ],
    tasks=[
        dict(label='1 · Rows vs columns', hint='Press <b>Run</b>. Which layout compresses better? Then change <code>items</code> to 50 different names and run again.', code=None),
        dict(label='2 · Dictionary encoding', hint='Columnar formats replace repeated strings with small numbers. Encode the <code>mode</code> column and compare sizes.',
             code='''import random
random.seed(2)
mode = [random.choice(["UPI", "cash", "card"]) for _ in range(10_000)]

dictionary = sorted(set(mode))                 # stored once
codes = [dictionary.index(m) for m in mode]    # 0, 1 or 2: fits in 2 bits

plain_bytes = sum(len(m) for m in mode)
encoded_bytes = len(codes) * 2 // 8 + sum(len(d) for d in dictionary)
print("dictionary:", dictionary)
print("plain text bytes  :", plain_bytes)
print("encoded (2 bits)  :", encoded_bytes)
'''),
        dict(label='3 · Run-length encoding', hint='Sorted columns have long runs of the same value. Encode them as (value, count) pairs. Try it on unsorted data too.',
             code='''canteen = ["C001"] * 500 + ["C002"] * 350 + ["C003"] * 150     # sorted by canteen
runs = []
for v in canteen:
    if runs and runs[-1][0] == v:
        runs[-1][1] += 1
    else:
        runs.append([v, 1])
print(len(canteen), "values ->", len(runs), "runs:", runs)
'''),
        dict(label='4 · Skip with min/max', hint='Each row group stores min and max per column. Which groups must be read for <code>WHERE amount &gt; 45</code>? Change the filter to 25.',
             code='''row_groups = {"rg1": (15, 40), "rg2": (15, 50), "rg3": (20, 30), "rg4": (40, 120)}
threshold = 45
for name, (lo, hi) in row_groups.items():
    print(name, "read" if hi > threshold else "skip", f"(min {lo}, max {hi})")
'''),
        dict(label='5 · Schema evolution (advanced)', hint='An old reader expects v1 fields; new records have an extra field; old records lack it. Read both with defaults, as Avro does.',
             code='''reader_schema = {"order_id": None, "item": None, "amount": 0, "coupon": None}   # field -> default
records = [{"order_id": 1, "item": "poha", "amount": 30},                         # written with v1
           {"order_id": 2, "item": "chai", "amount": 20, "coupon": "DIWALI10", "app": "2.0"}]  # v2
for r in records:
    resolved = {f: r.get(f, default) for f, default in reader_schema.items()}
    print(resolved)
'''),
        dict(label='6 · Bytes read by a query (advanced)', hint='A table has 12 monthly partitions, 6 columns of equal size and 4 row groups per file. A query filters one month, needs 2 columns and skips 1 row group. What fraction of the table is read?',
             code='''from fractions import Fraction
fraction = Fraction(1, 12) * Fraction(2, 6) * Fraction(3, 4)
print("fraction read:", fraction, "=", f"{float(fraction):.1%}")
print("of a 14 GB table:", round(14 * float(fraction) * 1024), "MB")
'''),
    ],
)
RUN['tasks'][0]['code'] = RUN['code']

PCRUN = dict(
    heading='Run it on your PC: one table, six files',
    intro='<p>This benchmark creates 10 lakh orders in memory, writes them as CSV, gzipped CSV, JSON Lines, Avro, Parquet and ORC, and times <code>SUM(amount)</code> on each. Then it opens the Parquet footer to show the schema and column statistics. Install the two libraries first: <code>pip install pyarrow fastavro</code>. Save it as <code>formats_bench.py</code> and run it; then look at the sizes in the <code>formats</code> folder.</p>',
    items=[
        dict(title='Size and query time for five formats', file='formats_bench.py',
             cmd=open(os.path.join(HERE, 'formats_bench.py')).read() + '\n# In a terminal:\n#   pip install pyarrow fastavro\n#   python formats_bench.py',
             output=open(os.path.join(HERE, 'formats_bench.out')).read(),
             note='Recorded from a real run (pyarrow 26, fastavro 1.13). Sizes will match; times depend on your computer. Compare “CSV, fast reader” with Parquet: same engine, about 10× faster, because Parquet reads one typed column. Parquet and ORC write times are low partly because the data was already in a columnar table in memory.'),
    ],
)

TRACE = dict(
    heading='Turning rows into columns',
    intro='<p>Follow three orders being rearranged into columns, the way a Parquet writer fills a row group, then summing one column.</p>',
    code='''rows = [(1, "poha", 30), (2, "chai", 20), (3, "poha", 30)]
columns = {"id": [], "item": [], "amount": []}
for order_id, item, amount in rows:
    columns["id"].append(order_id)
    columns["item"].append(item)
    columns["amount"].append(amount)
total = sum(columns["amount"])
print(columns)
print("SUM(amount) =", total)
''',
    notes={2: 'Empty columns :: One list per column: the writer buffers a row group like this.',
           (4, 1): 'Split a row :: Each field goes to its own column list.',
           7: 'One column :: The sum touches only the amount list, not ids or items.'},
)

WORKED_INTRO = 'Four problems on sizes, compression, splits and schema changes. Each runs live and is traced.'
EXAMPLES = [
    dict(level='b', tag='Basics · size', title='How much smaller is Parquet for a year of data?',
         problem='<p>In our benchmark, 10 lakh orders took 37.7 MB as CSV and 10.7 MB as Parquet. A year from 400 canteens is about 36.5 crore orders. Estimate both sizes in GB.</p>',
         inp='37.7 MB and 10.7 MB per 10 lakh orders · 36.5 crore orders',
         approach=['Scale factor = orders / 10 lakh.',
                   'Multiply each size by it.',
                   'Convert MB to GB.'],
         code='''scale = 365_000_000 / 1_000_000
for fmt, mb in [("CSV", 37.7), ("Parquet", 10.7), ("ORC", 4.2)]:
    print(f"{fmt:8} {mb * scale / 1024:6.1f} GB")
''', notes={1: 'Scale :: The benchmark is a sample; sizes grow roughly linearly with rows.'},
         tryit='Over 3 years with 3 replicas in HDFS, how much disk does the choice of format save?'),
    dict(level='i', tag='Compression · encoding', title='Measure how well a column compresses',
         problem='<p>Compress a low-variety column (payment mode) and a high-variety column (order ID) with zlib and compare ratios.</p>',
         inp='10,000 modes and 10,000 IDs',
         approach=['Build both columns as text.',
                   'Compress each with zlib.',
                   'Print the compression ratio.'],
         code='''import random, zlib
random.seed(5)
mode = ",".join(random.choice(["UPI", "cash", "card"]) for _ in range(10_000)).encode()
ids = ",".join(str(random.randint(10**8, 10**9)) for _ in range(10_000)).encode()
for name, col in [("mode", mode), ("order_id", ids)]:
    print(f"{name:9} {len(col):6} -> {len(zlib.compress(col)):6} bytes  ratio {len(col) / len(zlib.compress(col)):.1f}x")
''', notes={3: 'Low variety :: Only 3 distinct values: highly compressible.'},
         tryit='Columns with few distinct values (status, city, mode) compress far better than IDs and timestamps. Columnar formats exploit this per column.'),
    dict(level='i', tag='Parallelism · splits', title='How many tasks can read the file in parallel?',
         problem='<p>A 1 GB file is read by a cluster that creates one task per 128 MB split. How many tasks for: plain CSV, a single gzip CSV, Parquet with 128 MB row groups?</p>',
         inp='1 GB · 128 MB splits',
         approach=['Splittable formats: size / 128 MB tasks.',
                   'A single gzip file is not splittable: 1 task.',
                   'Parquet splits at row groups.'],
         code='''import math
size_mb, split_mb = 1024, 128
for fmt, splittable in [("CSV", True), ("CSV.gz (one file)", False), ("Parquet", True)]:
    tasks = math.ceil(size_mb / split_mb) if splittable else 1
    print(f"{fmt:18} {tasks} task(s)")
''', notes={3: 'Splittable :: Only if a reader can start in the middle of the file.'},
         tryit='With 8 tasks on 8 machines the read takes about 1/8 of the time; the gzip file uses one machine however big the cluster is.'),
    dict(level='a', tag='Evolution · compatibility', title='Is the new schema backward compatible?',
         problem='<p>A new reader schema must be able to read old records. Check: every field that old records lack must have a default. Test v2 (adds coupon with default) and v3 (adds rider_id without default).</p>',
         inp='old fields {order_id, item, amount}',
         approach=['Find fields in the new schema that are not in the old one.',
                   'Each must have a default.',
                   'Report compatible or not.'],
         code='''old = {"order_id", "item", "amount"}
new_schemas = {"v2": {"order_id": None, "item": None, "amount": None, "coupon": "none"},
               "v3": {"order_id": None, "item": None, "amount": None, "rider_id": None}}
for name, schema in new_schemas.items():
    added = [f for f in schema if f not in old]
    ok = all(schema[f] is not None for f in added)
    print(name, "adds", added, "-> backward compatible" if ok else "-> NOT compatible: old records have no value")
''', notes={5: 'Rule :: New fields need defaults so old data can be read.'},
         tryit='Schema registries run exactly this kind of check before accepting a new schema.'),
]

QUIZ = [
    dict(q='Beginner: Which format stores data column by column?', options=['CSV', 'JSON', 'Avro', 'Parquet'], answer=3,
         why='Parquet (and ORC) are columnar; CSV, JSON and Avro are row formats.'),
    dict(q='Beginner: In our benchmark, which file was the largest?', options=['CSV', 'JSON Lines', 'Parquet', 'ORC'], answer=1,
         why='JSON Lines: 104.7 MB, because every record repeats the field names.'),
    dict(q='Beginner: Which format is easiest to open in a spreadsheet?', options=['CSV', 'Avro', 'Parquet', 'ORC'], answer=0,
         why='CSV is plain text that every tool reads; the binary formats need libraries.'),
    dict(q='Intermediate: Why is SUM(amount) much faster from Parquet than from CSV?', options=['Parquet stores the sum', 'Parquet reads only the amount column, already typed, without parsing text', 'CSV is encrypted', 'Parquet uses more CPU cores always'], answer=1,
         why='Column pruning plus binary typed values: 0.013 s vs 0.125 s with the same reader.'),
    dict(q='Intermediate: What does predicate pushdown use to skip data?', options=['File names only', 'Min/max statistics per column chunk or stripe', 'Random sampling', 'The CSV header'], answer=1,
         why='A block whose max is below the filter value cannot match and is skipped.'),
    dict(q='Intermediate: Which format is most commonly used for messages on Kafka with schema evolution?', options=['CSV', 'Avro', 'ORC', 'XML'], answer=1,
         why='Avro: compact binary rows with a schema registry and default values.'),
    dict(q='Advanced: Why is one large .csv.gz file a problem for Spark or Hadoop?', options=['gzip is not allowed', 'It is not splittable, so only one task can read it', 'It loses data', 'It cannot be compressed further'], answer=1,
         why='gzip streams must be decompressed from the start, so the file can\'t be split among workers.'),
    dict(q='Advanced: Delta Lake and Apache Iceberg tables store their data files as…', options=['CSV', 'JSON', 'Parquet (usually)', 'Avro only'], answer=2,
         why='They add a transaction log on top of Parquet data files.'),
]

REVISION = [
    '<b>Row formats</b>: CSV (text), JSON (text, nested), Avro (binary, schema). <b>Columnar</b>: Parquet, ORC.',
    'Columnar wins for analytics: <b>column pruning</b>, better <b>compression</b>, <b>predicate pushdown</b> with min/max stats.',
    'Our run (10 lakh orders): CSV 37.7 MB, JSON 104.7, Avro 8.8, Parquet 10.7, ORC 4.2.',
    'SUM(amount): Parquet 0.013 s vs CSV 0.125 s with the same reader.',
    'Encodings: dictionary, run-length, bit-packing; codecs: snappy, zstd, gzip.',
    '<b>Splittable</b>: Parquet, ORC, Avro yes; a single gzip CSV no.',
    'Avro = schema evolution with defaults (Kafka). Parquet = lakes and Spark. ORC = Hive. CSV = exchange. JSON = APIs and logs.',
]
FAQ = [
    ('What is the difference between row-based and columnar file formats?', 'Row-based formats (CSV, JSON, Avro) store all fields of a record together, which suits writing records and reading whole records. Columnar formats (Parquet, ORC) store each column\'s values together, so analytical queries read only the needed columns, and similar values compress well. Columnar formats are preferred for analytics; row formats for ingestion and messaging.'),
    ('Why is Parquet preferred in big data?', 'It is columnar, typed and compressed per column, stores the schema and min/max statistics in the file footer, and is splittable by row groups. Engines can skip columns and row groups that a query doesn\'t need, which reduces I/O dramatically. It is also supported by almost every big data engine.'),
    ('What is the difference between Parquet and ORC?', 'Both are columnar with similar ideas. ORC came from the Hive project and is required for Hive ACID tables; it has stripe-level indexes and often compresses slightly better. Parquet came from Twitter and Cloudera, has excellent nested-data support and is the default in Spark and most lakehouse table formats.'),
    ('When would you use Avro?', 'For row-oriented, write-heavy workloads such as Kafka messages and ingestion, where records are written one at a time and schemas evolve. Avro is compact binary, stores the schema with the data (or in a registry), and supports adding fields with default values without breaking readers.'),
    ('What does splittable mean and why does it matter?', 'A file is splittable if it can be divided into parts that different workers read independently. Parallel engines create one task per split, so splittable files are processed by many machines at once. A gzip-compressed text file is not splittable and must be read by a single task.'),
]

PRACTICE_INTRO = 'Exercises from easy to advanced, ending with two business decisions.'
PROBLEMS = [
    dict(level='easy', title='Size ratios', stmt='From the benchmark sizes (MB), print each format\'s size as a percentage of CSV.', inp='CSV 37.7, JSON 104.7, Avro 8.8, Parquet 10.7, ORC 4.2',
         code='''sizes = {"CSV": 37.7, "JSON": 104.7, "Avro": 8.8, "Parquet": 10.7, "ORC": 4.2}
for f, s in sizes.items():
    print(f"{f:8} {s / sizes['CSV']:.0%}")
''', explain='JSON 278%, Avro 23%, Parquet 28%, ORC 11%, matching the benchmark output.'),
    dict(level='easy', title='Rows to columns', stmt='Turn three rows into a dictionary of columns.', inp='[(1,"poha",30),(2,"chai",20),(3,"dosa",40)]',
         code='''rows = [(1, "poha", 30), (2, "chai", 20), (3, "dosa", 40)]
ids, items, amounts = zip(*rows)
print({"id": ids, "item": items, "amount": amounts})
''', explain='zip(*rows) transposes rows into columns: the core move of a columnar writer.'),
    dict(level='easy', title='Row or column?', stmt='Print the better layout for each workload.', inp='4 workloads',
         code='''work = {"append one order at a time": "row (Avro)", "average amount over a year": "column (Parquet)",
        "show one customer's full record": "row", "count orders by city": "column"}
for w, f in work.items():
    print(f"{w:34} -> {f}")
''', explain='Whole records and appends favour rows; aggregates over few columns favour columns.'),
    dict(level='medium', title='Dictionary size', stmt='A city column has 1 crore values and 30 distinct cities (average 8 characters). Estimate plain size vs dictionary encoding with 5-bit codes.', inp='1,00,00,000 values · 30 cities',
         code='''n, distinct, avg = 10_000_000, 30, 8
plain = n * avg
encoded = n * 5 // 8 + distinct * avg
print(f"plain {plain / 1e6:.0f} MB, dictionary {encoded / 1e6:.2f} MB")
''', explain='80 MB vs about 6.25 MB before any compression codec.'),
    dict(level='medium', title='Row groups to read', stmt='Given (min, max) of <code>ts</code> per row group, list the groups a query for ts between 500 and 700 must read.', inp='4 row groups',
         code='''groups = {"rg1": (0, 300), "rg2": (290, 610), "rg3": (600, 900), "rg4": (910, 1200)}
lo, hi = 500, 700
print([g for g, (a, b) in groups.items() if b >= lo and a <= hi])
''', explain='rg2 and rg3 overlap the range; rg1 and rg4 are skipped using statistics alone.'),
    dict(level='medium', title='Tasks for gzip files', stmt='A day of logs is 64 files of 2 GB each, gzip-compressed. How many tasks can read them in parallel? And if it were one 128 GB gzip file?', inp='64 × 2 GB vs 1 × 128 GB',
         code='''print("64 files :", 64, "tasks (one per file)")
print("1 file   :", 1, "task")
''', explain='Non-splittable files still parallelise across files, so many moderate files beat one huge one.'),
    dict(level='advanced', title='Real compression per column', stmt='Compress each column of 5,000 random orders separately with zlib and print the compressed size per column.', inp='4 columns',
         code='''import random, zlib
random.seed(9)
rows = [(i, random.choice(["chai", "poha", "dosa"]), random.choice([15, 20, 30]), random.choice(["UPI", "cash"])) for i in range(5000)]
for name, col in zip(["id", "item", "amount", "mode"], zip(*rows)):
    raw = ",".join(map(str, col)).encode()
    print(f"{name:7} {len(raw):6} -> {len(zlib.compress(raw)):5} bytes")
''', explain='Low-variety columns shrink dramatically; IDs barely. Columnar formats choose encodings per column.'),
    dict(level='business', title='Storage bill by format', stmt='A lake holds 50 TB of CSV. Converting to Parquet makes it 28% of the size. Object storage costs ₹1.8 per GB per month. Print the monthly saving.', inp='50 TB · 28% · ₹1.8/GB',
         code='''csv_gb = 50 * 1024
parquet_gb = csv_gb * 0.28
print(f"Rs {(csv_gb - parquet_gb) * 1.8:,.0f} saved per month")
''', explain='About ₹66,355 per month on storage alone (prices illustrative), plus big savings on query engines that charge per byte scanned.'),
    dict(level='business', title='Pay per byte scanned', stmt='A query engine charges ₹400 per TB scanned. A daily report scans a 2 TB CSV table, or 2% of a Parquet version of it. Print the yearly cost of each.', inp='2 TB · 2% · ₹400/TB · 365 days',
         code='''csv_cost = 2 * 400 * 365
parquet_cost = 2 * 0.28 * 0.02 * 400 * 365
print(f"CSV: Rs {csv_cost:,.0f}  Parquet: Rs {parquet_cost:,.0f} per year")
''', explain='₹2.92 lakh vs about ₹1,635 a year (illustrative): with per-byte pricing, file format is a direct cost decision.'),
]

SCN_INTRO = 'File format questions asked in data engineering interviews. Decide your answer first, then open the model answer.'
SCENARIOS = open(os.path.join(HERE, 'scenarios.html'), encoding='utf-8').read()
