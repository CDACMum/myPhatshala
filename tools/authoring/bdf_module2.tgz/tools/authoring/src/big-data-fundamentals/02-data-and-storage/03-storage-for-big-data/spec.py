import os
HERE = os.path.dirname(os.path.abspath(__file__))
BODY = body(HERE)

META = dict(
    module='02-data-and-storage', lesson='03-storage-for-big-data', n='2.3',
    module_label='Module 2 · Data and Storage',
    title='Storage for big data: block, file and object storage',
    desc='Block, file and object storage explained with real behaviour on your own laptop: 4 KB blocks, a folder of 2,000 files renamed in 0.04 ms, and the same rename in an S3-style object store taking 306 ms as copy-and-delete. Keys, metadata, ETags, storage tiers and lifecycle rules, S3 consistency, why data lakes use object storage, and HDFS vs S3. Beginner to Advanced, animations, Python exercises and a demo for your PC.',
    og_desc='Same disks, three interfaces, three bills. Learn block, file and object storage, and why renaming a folder in S3 is slow.',
    minutes=28, level='Beginner → Advanced',
    lead='Databases, shared drives and data lakes all store bytes on disks, but they use them in three different ways: as numbered blocks, as a tree of files, or as a flat store of whole objects. This lesson shows each one\'s behaviour on your own computer, builds a tiny S3-style object store in Python, and explains which storage big data platforms choose and why.',
    chips=['Runs in your browser (Python)', '3 real-time scenarios', 'Mini object store on your PC'],
)

RUN = dict(
    heading='A tiny object store vs a file tree',
    intro='<p>Two dictionaries play the two systems. The <b>file tree</b> nests folders inside folders, so renaming a folder is one change. The <b>object store</b> is flat: each key maps to a whole object. Run it and count the operations each needs to “rename” a month of orders.</p>',
    code='''# FILE STORAGE: a tree. A folder is one entry that holds its files.
tree = {"orders": {"2026-10": {f"part-{i}.csv": b"1,30" for i in range(1000)}}}

ops = 0
tree["orders"]["october"] = tree["orders"].pop("2026-10")     # rename the folder
ops += 1
print("file tree rename   :", ops, "operation")

# OBJECT STORAGE: flat keys. 'orders/2026-10/' is only part of each name.
bucket = {f"orders/2026-10/part-{i}.csv": b"1,30" for i in range(1000)}

ops = 0
for key in [k for k in bucket if k.startswith("orders/2026-10/")]:
    bucket[key.replace("2026-10", "october")] = bucket[key]     # copy
    del bucket[key]                                               # delete
    ops += 2
print("object store rename:", ops, "operations")
print("objects now under 'orders/october/':", sum(k.startswith("orders/october/") for k in bucket))
''',
    anno=[
        ('tree["orders"]["october"] = tree["orders"].pop("2026-10")     # rename the folder', 'In a file system the folder is a single entry, so one change moves everything inside it.'),
        ('bucket = {f"orders/2026-10/part-{i}.csv": b"1,30" for i in range(1000)}', 'An object store has no folders. The “/” is just a character in each key. Tools show prefixes as folders for convenience.'),
        ('    ops += 2', 'Each object needs a copy and a delete: on S3 these are two HTTP requests, each billed and each taking milliseconds.'),
    ],
    tasks=[
        dict(label='1 · Rename a month', hint='Press <b>Run</b>. Change 1000 to 100000. Which count changes?', code=None),
        dict(label='2 · Wasted space in blocks', hint='Files occupy whole 4 KB blocks. How much disk do 10 lakh files of 300 bytes really use? Try 64 MB files.',
             code='''import math
block = 4096
files, size = 1_000_000, 300
used = files * math.ceil(size / block) * block
print(f"data {files * size / 1e9:.2f} GB, disk used {used / 1e9:.2f} GB")
'''),
        dict(label='3 · ETag changes on rewrite', hint='Objects are replaced whole; the ETag (here MD5) tells you the content changed. Change one character and compare.',
             code='''import hashlib
v1 = b"order_id,amount\\n1,30\\n"
v2 = b"order_id,amount\\n1,34\\n"
print("ETag v1:", hashlib.md5(v1).hexdigest())
print("ETag v2:", hashlib.md5(v2).hexdigest())
print("same content?", hashlib.md5(v1).digest() == hashlib.md5(v2).digest())
'''),
        dict(label='4 · List by prefix', hint='Listing a “folder” in an object store means filtering keys by prefix. List only canteen C017’s photos.',
             code='''keys = ["photos/C017/menu.jpg", "photos/C017/kitchen.jpg", "photos/C233/menu.jpg",
        "cctv/C017/0900.mp4", "orders/2026-10/part-0.csv"]
prefix = "photos/"
print([k for k in keys if k.startswith(prefix)])
'''),
        dict(label='5 · Tiering bill (advanced)', hint='3 TB of CCTV arrives every day and is kept 365 days. Compare the monthly bill if everything stays hot with a 7-day hot / 23-day cool / rest archive rule.',
             code='''tb_per_day = 3
price = {"hot": 1.8, "cool": 1.0, "archive": 0.1}      # Rs per GB per month (illustrative)
all_hot = tb_per_day * 365 * 1000 * price["hot"]
tiered = (tb_per_day * 7 * price["hot"] + tb_per_day * 23 * price["cool"]
          + tb_per_day * 335 * price["archive"]) * 1000
print(f"all hot: Rs {all_hot:,.0f}  tiered: Rs {tiered:,.0f}  per month")
'''),
        dict(label='6 · Request cost of small files (advanced)', hint='Object stores charge per request. Writing 1 crore tiny objects vs 100 big ones: compare request charges at ₹0.4 per 1,000 PUTs.',
             code='''price_per_1000 = 0.4
for name, objects in [("tiny files", 10_000_000), ("compacted", 100)]:
    print(f"{name:10} {objects:>10,} PUTs -> Rs {objects / 1000 * price_per_1000:,.2f}")
'''),
    ],
)
RUN['tasks'][0]['code'] = RUN['code']

PCRUN = dict(
    heading='Run it on your PC: block, file and object behaviour',
    intro='<p>This program shows your disk\'s block size, renames a folder of 2,000 files and edits a file in place, then builds a <b>mini object store</b> on a local folder that follows S3\'s rules: flat keys, metadata and an ETag per object, list by prefix, no rename and no partial update. It cleans up after itself. No extra libraries needed. Save it as <code>storage_kinds.py</code> and run it.</p>',
    items=[
        dict(title='Three kinds of storage on one laptop', file='storage_kinds.py',
             cmd=open(os.path.join(HERE, 'storage_kinds.py')).read() + '\n# In a terminal:  python storage_kinds.py',
             output=open(os.path.join(HERE, 'storage_kinds.out')).read(),
             note='Recorded from a real run on Linux. Times differ on your computer, but the gap stays huge: one metadata change for the folder rename, 4,000 operations for the object store. On Windows, step 1 prints a note instead of block details.'),
    ],
)

TRACE = dict(
    heading='“Renaming” objects one by one',
    intro='<p>Follow a rename of three objects in a flat bucket: each key is copied to a new name and the old key deleted. Watch the bucket change step by step.</p>',
    code='''bucket = {"oct/a.csv": 1, "oct/b.csv": 2, "nov/c.csv": 3}
moved = 0
for key in list(bucket):
    if key.startswith("oct/"):
        bucket["october/" + key[4:]] = bucket[key]
        del bucket[key]
        moved += 1
print(bucket, moved)
''',
    notes={3: 'Snapshot :: list(bucket) copies the keys first, so we can change the dict while looping.',
           (5, 1): 'Copy :: A new object under the new key (a PUT or COPY request on S3).',
           (6, 1): 'Delete :: The old key is removed. Between these two steps, both exist.'},
)

WORKED_INTRO = 'Four problems on storage choice, costs and behaviour. Each runs live and is traced.'
EXAMPLES = [
    dict(level='b', tag='Basics · choose', title='Which storage for each kind of data?',
         problem='<p>Choose block, file or object storage for: the orders database, students\' shared project folders, 1 PB of CCTV video, and the data lake\'s Parquet tables.</p>',
         inp='4 workloads',
         approach=['Small in-place updates by one server → block.',
                   'Many people sharing folders → file.',
                   'Huge, write-once, read-many data → object.'],
         code='''choice = {"orders database": "block (one server, in-place updates)",
          "shared project folders": "file (NFS/SMB share)",
          "CCTV video, 1 PB": "object (cheap, unlimited, tiers)",
          "data lake Parquet tables": "object (many engines share it)"}
for data, store in choice.items():
    print(f"{data:26} -> {store}")
''', notes={1: 'Match access pattern :: Ask how data is updated and who reads it.'},
         tryit='Where would HDFS fit in this list? (A distributed file system: on-premise lakes.)'),
    dict(level='i', tag='Cost · growth', title='Storage growing faster than compute',
         problem='<p>Data grows 40 TB per month; processing needs stay the same. An HDFS node holds 48 TB usable (after 3 replicas, 16 TB of data) and costs ₹6 lakh. Object storage costs ₹1.8 per GB per month. Compare the cost of the next 12 months of growth.</p>',
         inp='40 TB/month · 16 TB data per node · ₹6 lakh/node · ₹1.8/GB/month',
         approach=['Nodes needed for 480 TB of new data.',
                   'Object cost: sum of monthly bills as data grows.',
                   'Compare.'],
         code='''import math
new_tb = 40 * 12
nodes = math.ceil(new_tb / 16)
object_cost = sum(40 * m * 1000 * 1.8 for m in range(1, 13))
print("HDFS: buy", nodes, "nodes -> Rs", f"{nodes * 6:,} lakh (plus power, space, staff)")
print(f"Object storage: Rs {object_cost / 1e5:,.0f} lakh over the year (pay as you grow)")
''', notes={3: 'Coupled :: With HDFS you also buy CPUs you may not need.'},
         tryit='In year one, object storage is far cheaper. But its bill keeps rising every month as data piles up, while nodes are bought once (then need power, space and staff). Extend the comparison to 60 months: the answer depends on your horizon and on who runs the hardware.'),
    dict(level='i', tag='Behaviour · updates', title='Correcting one row: cost in each system',
         problem='<p>One amount in a 512 MB file must be corrected. How many bytes are written on block storage (4 KB blocks), on a file system (same), and on object storage (whole object)?</p>',
         inp='512 MB file · 4 KB block',
         approach=['Block/file: only the changed block is rewritten.',
                   'Object: the whole object is uploaded again.',
                   'Compare.'],
         code='''block = 4 * 1024
file_size = 512 * 1024 * 1024
print("block/file storage writes:", block, "bytes")
print("object storage writes    :", file_size, "bytes")
print("ratio:", file_size // block, "x")
''', notes={3: 'Whole object :: Objects are immutable; changes create a new object.'},
         tryit='This is why lakes do not update rows in place: table formats write new small files and record the change in a log.'),
    dict(level='a', tag='Design · commit', title='How long does a rename-based commit take on S3?',
         problem='<p>A job writes 20,000 files. A copy request takes 60 ms and a delete 20 ms, with 50 requests in parallel. Estimate the commit time, and compare with an HDFS rename of 5 ms.</p>',
         inp='20,000 files · 60 + 20 ms · 50 parallel',
         approach=['Time per file = copy + delete.',
                   'Divide by parallelism.',
                   'Compare with one rename.'],
         code='''files, copy_ms, delete_ms, parallel = 20_000, 60, 20, 50
seconds = files * (copy_ms + delete_ms) / parallel / 1000
print(f"object store commit: {seconds:.0f} s (and not atomic)")
print("HDFS rename        : 0.005 s (atomic)")
''', notes={2: 'Parallel :: Clients issue many requests at once, but the total work stays 40,000 requests.'},
         tryit='Real numbers depend on file sizes (copy time grows with size). That is why S3A committers and table formats avoid this step.'),
]

QUIZ = [
    dict(q='Beginner: Which storage type gives a server raw, numbered blocks?', options=['Block storage', 'File storage', 'Object storage', 'Tape'], answer=0,
         why='Block storage exposes a volume of fixed-size blocks; the server puts its own file system on it.'),
    dict(q='Beginner: Amazon S3, Azure Blob Storage and Google Cloud Storage are…', options=['Block storage', 'File storage', 'Object storage', 'Databases'], answer=2,
         why='Flat buckets of objects with keys and metadata, accessed over HTTP.'),
    dict(q='Beginner: Which protocols share files over a network?', options=['NFS and SMB', 'HTTP and FTP only', 'TCP and UDP', 'SQL and JDBC'], answer=0,
         why='NFS (Linux/Unix) and SMB (Windows) serve file storage from a NAS.'),
    dict(q='Intermediate: Why is “renaming a folder” slow on plain object storage?', options=['Objects are encrypted', 'There are no real folders; each object must be copied to a new key and the old one deleted', 'Buckets are read-only', 'Keys cannot contain slashes'], answer=1,
         why='In our run: 0.04 ms on a file system vs 306 ms for 2,000 objects, and on S3 that is 4,000 requests.'),
    dict(q='Intermediate: How do you change one value inside an object?', options=['Seek and overwrite the byte', 'Upload a new version of the whole object', 'Append to it', 'Edit its metadata'], answer=1,
         why='Objects are written whole; the ETag changes with the content.'),
    dict(q='Intermediate: Why do most cloud data lakes use object storage?', options=['It is the fastest for single-row updates', 'It is cheap per TB, scales without limits, is very durable and can be shared by many engines', 'It needs no network', 'It supports SQL natively'], answer=1,
         why='And it separates storage from compute.'),
    dict(q='Advanced: Since December 2020, Amazon S3 reads after writes are…', options=['Eventually consistent', 'Strongly consistent', 'Not guaranteed', 'Consistent only in one region per day'], answer=1,
         why='S3 provides strong read-after-write consistency for PUTs, deletes and lists.'),
    dict(q='Advanced: What do table formats like Iceberg and Delta Lake do to avoid slow renames?', options=['Disable writes', 'Write data files in place and commit by adding an entry to a metadata log', 'Store everything in one file', 'Use block storage'], answer=1,
         why='The commit is one small atomic metadata write, not thousands of renames.'),
]

REVISION = [
    '<b>Block</b>: numbered blocks for one host; in-place updates; databases, VM disks (SAN, EBS).',
    '<b>File</b>: folders and files shared over NFS/SMB; rename is a metadata change; NAS, EFS, HDFS.',
    '<b>Object</b>: flat keys + metadata + ETag over HTTP; whole-object writes; unlimited and cheap (S3, Blob, GCS, MinIO).',
    'Our run: block 4 KB; folder of 2,000 files renamed in 0.04 ms; same “rename” of objects 306 ms (copy + delete).',
    'Objects have no folders: “/” is part of the key; listing uses prefixes.',
    'Tiers (hot, cool, archive) + lifecycle rules cut costs for old data.',
    'Lakes use object storage: separation of compute and storage; avoid rename-based commits (use committers/table formats).',
]
FAQ = [
    ('What is the difference between block, file and object storage?', 'Block storage presents raw fixed-size blocks to one server, which manages its own file system on top; it suits databases. File storage presents a shared hierarchy of folders and files over NFS or SMB to many clients. Object storage keeps whole objects with keys and metadata in a flat namespace accessed by HTTP APIs; it scales almost without limit at low cost and suits data lakes, backups and media.'),
    ('Why is object storage used for data lakes?', 'It is inexpensive per terabyte, highly durable, scales to petabytes without capacity planning, and is accessible over HTTP by many engines at once. Storing data there separates storage from compute, so processing clusters can be resized or turned off independently.'),
    ('Is HDFS block, file or object storage?', 'HDFS is a distributed file system: it offers a file and folder namespace (managed by the NameNode) while internally splitting files into large blocks stored on DataNodes. It is file storage from the user\'s point of view.'),
    ('Can you modify part of an object in S3?', 'No. Objects are immutable; to change content you upload a new object under the same key, which replaces it. Some services offer append-like features or multipart uploads, but in-place edits are not supported as on a file system.'),
    ('What are storage classes or tiers?', 'Options with different prices and access characteristics: hot (frequent access, highest storage price), cool or infrequent access (cheaper storage, fee per retrieval) and archive (cheapest storage, retrieval can take hours). Lifecycle rules move objects between tiers or delete them by age.'),
]

PRACTICE_INTRO = 'Exercises from easy to advanced, ending with two business decisions.'
PROBLEMS = [
    dict(level='easy', title='Pick the storage', stmt='Print block, file or object for: MySQL data files, a team\'s shared folder, backup archives.', inp='3 workloads',
         code='''for w, s in [("MySQL data files", "block"), ("team shared folder", "file"), ("backup archives", "object")]:
    print(f"{w:20} {s}")
''', explain='In-place database writes → block; sharing → file; large write-once data → object.'),
    dict(level='easy', title='Split a key', stmt='Split the key <code>orders/2026-10/C017/part-0003.parquet</code> into its prefix and object name.', inp='one key',
         code='''key = "orders/2026-10/C017/part-0003.parquet"
prefix, name = key.rsplit("/", 1)
print("prefix:", prefix, "| name:", name)
''', explain='The “folders” are just the prefix part of the key.'),
    dict(level='easy', title='Blocks for a file', stmt='How many 4 KB blocks does a 10,000-byte file need?', inp='10,000 bytes',
         code='''import math
print(math.ceil(10_000 / 4096), "blocks")
''', explain='3 blocks (12,288 bytes) because blocks are allocated whole.'),
    dict(level='medium', title='Objects per prefix', stmt='Count objects per top-level prefix in a bucket listing.', inp='6 keys',
         code='''from collections import Counter
keys = ["raw/a.json", "raw/b.json", "curated/x.parquet", "raw/c.json", "logs/1.txt", "curated/y.parquet"]
print(Counter(k.split("/")[0] for k in keys))
''', explain='raw: 3, curated: 2, logs: 1. Inventory reports like this help find runaway small files.'),
    dict(level='medium', title='Detect a changed object', stmt='Two downloads of the same key have different ETags. Write a check that decides whether to reprocess.', inp='etag_before, etag_now',
         code='''etag_before, etag_now = "a75a41efda982df331aa4f48233f027b", "e9fcc0e75a7e8c08a2d185f1a8107ee8"
print("reprocess" if etag_before != etag_now else "skip, unchanged")
''', explain='Pipelines compare ETags (or versions) to process only objects that changed.'),
    dict(level='medium', title='Rename cost', stmt='How many requests does it take to “rename” a prefix with 75,000 objects, and how long at 400 requests per second?', inp='75,000 objects',
         code='''objects, rps = 75_000, 400
requests = objects * 2
print(requests, "requests,", round(requests / rps / 60, 1), "minutes")
''', explain='1,50,000 requests, about 6 minutes, versus one instant rename on a file system.'),
    dict(level='advanced', title='Lifecycle rule', stmt='Given object ages in days, print the tier each should be in under the rule: ≤7 hot, ≤30 cool, ≤365 archive, else delete.', inp='ages 2, 15, 120, 400',
         code='''def tier(age):
    return "hot" if age <= 7 else "cool" if age <= 30 else "archive" if age <= 365 else "delete"
for age in [2, 15, 120, 400]:
    print(age, "days ->", tier(age))
''', explain='This is exactly what an object store lifecycle policy automates.'),
    dict(level='business', title='Tiering saving', stmt='1,095 TB of video: 21 TB hot (₹1.8/GB), 69 TB cool (₹1.0/GB), the rest archive (₹0.1/GB). Compare with all hot.', inp='1,095 TB',
         code='''all_hot = 1095 * 1000 * 1.8
tiered = (21 * 1.8 + 69 * 1.0 + (1095 - 21 - 69) * 0.1) * 1000
print(f"all hot Rs {all_hot / 1e5:.1f} lakh, tiered Rs {tiered / 1e5:.1f} lakh per month")
''', explain='About ₹19.7 lakh vs ₹2.1 lakh per month (illustrative prices): tiering is the main lever for large archives.'),
    dict(level='business', title='Egress surprise', stmt='A partner downloads 50 TB a month from your bucket. Egress costs ₹7 per GB. What is the monthly egress bill?', inp='50 TB × ₹7/GB',
         code='''print(f"Rs {50 * 1000 * 7:,} per month")
''', explain='₹3.5 lakh per month (illustrative). Moving data out of a cloud can cost more than storing it; plan sharing carefully.'),
]

SCN_INTRO = 'Storage questions asked in data engineering and cloud interviews. Decide your answer first, then open the model answer.'
SCENARIOS = open(os.path.join(HERE, 'scenarios.html'), encoding='utf-8').read()
